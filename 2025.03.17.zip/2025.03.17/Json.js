//JSON
//{key:value}

let Student = {RegNo:'2021/ICT/01', Name:'Ryan', Age:21, Course:'IT', Skills:['Java','Python','C++']}
console.log(Student)
console.log(Student.Name)

console.log("More Values")

let Students = [
				{RegNo:'2021/ICT/01', Name:'Ryan', Age:21, Course:'IT'},
				{RegNo:'2021/ICT/05', Name:'James', Age:23, Course:'IT'},
				{RegNo:'2021/ICT/07', Name:'Shohan', Age:22, Course:'IT'}
]

console.log(Students)